import { useState, useEffect, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  FaPhone, FaEnvelope, FaMapMarkerAlt, FaClock, FaWhatsapp,
  FaLinkedin, FaTwitter, FaFacebook, FaInstagram,
  FaChevronUp, FaArrowRight, FaCheckCircle, FaStar,
  FaCalculator, FaFileAlt, FaChartLine, FaBuilding,
  FaUserTie, FaShieldAlt, FaHandshake, FaAward,
  FaSearch, FaBalanceScale, FaGlobe, FaHeadset,
  FaRegClock, FaTrophy, FaLightbulb,
  FaIndustry, FaHospital, FaShoppingCart, FaHome,
  FaGraduationCap, FaTruck, FaHotel, FaCode,
  FaBars, FaTimes
} from 'react-icons/fa';
import CountUp from 'react-countup';
const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxOAvDdgRKPvGoQQinW1RyEyqurzIjayEfHjQjA4jcIUH43Tr2MAG5_P19FgaPLW-ve2g/exec'; // Paste the URL from Step 1

/* ========== HERO SECTION ========== */
function HeroSection() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', service: '', message: '' });

const [submitted, setSubmitted] = useState(false);
const [loading, setLoading] = useState(false);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);

  try {
    await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        service: formData.service,
        message: formData.message,
        company: 'N/A',
      }),
    });

    setSubmitted(true);
    setFormData({ name: '', email: '', phone: '', service: '', message: '' });
    setTimeout(() => setSubmitted(false), 3000);

  } catch (error) {
    console.error('Submission error:', error);
    alert('Failed to submit. Please try again.');
  } finally {
    setLoading(false);
  }
};

  return (
    <section className="hero-section" id="home">
      <div
        className="hero-bg-image"
        style={{ backgroundImage: "url('/images/hero-bg.jpg')" }}
      />
      <div className="hero-overlay" />
      <div className="hero-pattern" />

      <div className="container position-relative" style={{ zIndex: 2, paddingTop: '100px' }}>
        <div className="row align-items-center g-5 py-5">

          {/* LEFT CONTENT */}
          <div className="col-lg-7">
            <div className="hero-badge animate-fade-up">
              <span className="hero-badge-dot"></span>
              Trusted Tax & Audit Advisors
            </div>
            <h1 className="hero-title animate-fade-up delay-100">
              Expert Tax Solutions <br />
              for <span>Businesses &</span><br />
              Individuals
            </h1>
            <p className="hero-desc animate-fade-up delay-200">
              Shanu's Tax Consulting & Auditing delivers comprehensive tax advisory, 
              auditing, and financial compliance services. We help you navigate complex 
              tax landscapes with precision and confidence — maximizing savings while 
              ensuring full legal compliance.
            </p>
            <div className="d-flex flex-wrap gap-3 animate-fade-up delay-300">
              <a href="#contact" className="hero-btn-primary">
                Get Free Consultation <FaArrowRight />
              </a>
              <a href="#services" className="hero-btn-secondary">
                Explore Services <FaArrowRight />
              </a>
            </div>
            <div className="hero-stats-row animate-fade-up delay-400">
              {[
                { number: '15+', label: 'Years Experience' },
                { number: '2500+', label: 'Clients Served' },
                { number: '98%', label: 'Client Satisfaction' },
                { number: '50+', label: 'Expert Advisors' },
              ].map((stat, i) => (
                <div key={i} className="d-flex align-items-center">
                  {i > 0 && <div className="hero-divider me-3" />}
                  <div className="hero-stat-item">
                    <div className="hero-stat-number">{stat.number}</div>
                    <div className="hero-stat-label">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT - CONTACT FORM */}
          <div className="col-lg-5 animate-fade-right delay-300">
            <div className="hero-right-card">
              <div className="consult-form-title">Book a Free Consultation</div>
              <div className="consult-form-subtitle">Our experts will get back to you within 24 hours</div>
              {submitted ? (
                <div className="text-center py-4">
                  <FaCheckCircle style={{ fontSize: '3rem', color: '#4caf50' }} />
                  <p className="mt-3" style={{ color: 'white', fontFamily: 'Montserrat', fontWeight: 600 }}>
                    Thank you! We'll contact you shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <input
                      type="text"
                      className="form-control form-control-custom"
                      placeholder="Your Full Name"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <input
                      type="email"
                      className="form-control form-control-custom"
                      placeholder="Email Address"
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <input
                      type="tel"
                      className="form-control form-control-custom"
                      placeholder="Phone Number"
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                  <div className="mb-3">
                    <select
                      className="form-control form-control-custom"
                      value={formData.service}
                      onChange={e => setFormData({...formData, service: e.target.value})}
                      required
                    >
                      <option value="" style={{ background: '#1a3a5c' }}>Select Service</option>
                      <option value="tax" style={{ background: '#1a3a5c' }}>Tax Consulting</option>
                      <option value="audit" style={{ background: '#1a3a5c' }}>Auditing & Assurance</option>
                      <option value="vat" style={{ background: '#1a3a5c' }}>VAT Services</option>
                      <option value="accounting" style={{ background: '#1a3a5c' }}>Accounting Services</option>
                      <option value="cfo" style={{ background: '#1a3a5c' }}>CFO Services</option>
                    </select>
                  </div>
                  <div className="mb-3">
                    <textarea
                      className="form-control form-control-custom"
                      rows={3}
                      placeholder="Brief description of your requirements..."
                      value={formData.message}
                      onChange={e => setFormData({...formData, message: e.target.value})}
                    />
                  </div>

<button 
  type="submit" 
  className="form-submit-btn"
  disabled={loading}
  style={{ opacity: loading ? 0.6 : 1 }}
>
  {loading ? 'Submitting...' : 'Request Free Consultation →'}
</button>
                </form>
              )}
              <div className="d-flex align-items-center justify-content-center gap-3 mt-3">
                <span style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.4)', fontFamily: 'Montserrat' }}>
                  🔒 100% Confidential &amp; Secure
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========== TICKER STRIP ========== */
function TickerStrip() {
  const items = [
    'Corporate Tax Advisory', 'VAT Registration & Filing', 'Financial Auditing',
    'Tax Compliance & Planning', 'CFO Services', 'Business Consulting',
    'Internal Audit Services', 'Payroll Management', 'Accounting & Bookkeeping',
    'Transfer Pricing', 'Tax Dispute Resolution', 'Due Diligence',
  ];

  return (
    <div className="ticker-strip">
      <div className="ticker-content">
        {[...items, ...items].map((item, i) => (
          <div key={i} className="ticker-item">
            <span className="ticker-dot" />
            {item}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ========== ABOUT SECTION ========== */
function AboutSection() {
  const features = [
    {
      icon: <FaShieldAlt />,
      title: 'Licensed & Certified Professionals',
      text: 'Our team comprises CPA, CA, and ACCA-certified professionals with deep industry expertise.'
    },
    {
      icon: <FaHandshake />,
      title: 'Client-First Philosophy',
      text: 'We build long-term relationships by putting your financial goals at the center of everything we do.'
    },
    {
      icon: <FaChartLine />,
      title: 'Data-Driven Tax Strategies',
      text: 'Leverage advanced analytics and real-time data to optimize your tax position and reduce liability.'
    },
    {
      icon: <FaGlobe />,
      title: 'Global Tax Expertise',
      text: 'Navigate international tax laws, cross-border transactions, and multi-jurisdiction compliance with ease.'
    },
  ];

  return (
    <section className="about-section section-padding" id="about">
      <div className="container">
        <div className="row align-items-center g-5">
          <div className="col-lg-6">
            <div className="about-img-wrapper animate-fade-left">
              <img src="/images/about-team.jpg" alt="Our Expert Team" />
              <div className="about-img-overlay">
                <p style={{ color: 'rgba(255,255,255,0.8)', fontFamily: 'Inter', fontSize: '0.85rem', margin: 0 }}>
                  "Excellence in every consultation"
                </p>
              </div>
              <div className="about-exp-badge">
                <div className="about-exp-number">15+</div>
                <div className="about-exp-label">Years of <br/>Excellence</div>
              </div>
            </div>
          </div>

          <div className="col-lg-6 animate-fade-right">
            <div className="section-tag">About Us</div>
            <h2 className="section-title">
              Your Trusted Partner in <span>Tax & Finance</span>
            </h2>
            <div className="section-divider" />
            <p className="section-desc mb-4">
              Shanu's Tax Consulting & Auditing is a premier financial advisory firm dedicated to 
              delivering exceptional tax, audit, and accounting services. Founded with a passion for 
              helping businesses thrive, we combine deep technical expertise with personalized attention 
              to deliver solutions that make a real difference.
            </p>
            <p className="section-desc mb-4">
              From startups to multinational corporations, we serve clients across all industries, 
              providing tailored strategies that optimize tax efficiency, ensure compliance, and 
              drive sustainable financial growth.
            </p>

            <div className="mb-4">
              {features.map((f, i) => (
                <div key={i} className="about-feature-item">
                  <div className="about-feature-icon">{f.icon}</div>
                  <div>
                    <div className="about-feature-title">{f.title}</div>
                    <div className="about-feature-text">{f.text}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="d-flex flex-wrap gap-2 mb-4">
              {['CPA Certified', 'CA Certified', 'ACCA Members', 'ISO Compliant'].map((cert, i) => (
                <span key={i} className="certification-badge">✓ {cert}</span>
              ))}
            </div>

            <a href="#contact" className="btn-gold" style={{ textDecoration: 'none', display: 'inline-block' }}>
              Learn More About Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========== SERVICES SECTION ========== */
function ServicesSection() {
  const services = [
    {
      img: '/images/tax-consulting.jpg',
      icon: <FaCalculator />,
      title: 'Tax Consulting & Planning',
      desc: 'Strategic tax planning and advisory services to minimize your tax burden while maintaining full compliance with all applicable tax laws and regulations.',
      features: ['Corporate Tax', 'Individual Tax', 'International Tax', 'Tax Optimization'],
    },
    {
      img: '/images/audit-services.jpg',
      icon: <FaSearch />,
      title: 'Auditing & Assurance',
      desc: 'Independent, thorough audit services that provide stakeholders with confidence in your financial statements and internal controls.',
      features: ['External Audit', 'Internal Audit', 'Compliance Audit', 'Forensic Audit'],
    },
    {
      img: '/images/vat-services.jpg',
      icon: <FaBalanceScale />,
      title: 'VAT Services',
      desc: 'End-to-end VAT registration, filing, and advisory services to ensure full compliance and optimize your VAT position across all jurisdictions.',
      features: ['VAT Registration', 'VAT Returns', 'VAT Advisory', 'VAT Refunds'],
    },
    {
      img: '/images/business-consulting.jpg',
      icon: <FaChartLine />,
      title: 'Business Consulting',
      desc: 'Comprehensive business advisory services to help you make informed decisions, improve financial performance, and achieve your strategic objectives.',
      features: ['Financial Analysis', 'Business Planning', 'M&A Advisory', 'Risk Management'],
    },
    {
      img: '/images/cfo-services.jpg',
      icon: <FaUserTie />,
      title: 'CFO Services',
      desc: 'Virtual CFO solutions providing executive-level financial leadership and strategic guidance without the cost of a full-time C-suite executive.',
      features: ['Financial Strategy', 'Cash Flow Mgmt', 'Investor Relations', 'Board Reporting'],
    },
    {
      img: '/images/tax-consulting.jpg',
      icon: <FaFileAlt />,
      title: 'Accounting & Bookkeeping',
      desc: 'Accurate, timely, and comprehensive accounting and bookkeeping services to keep your financial records in perfect order and business-ready.',
      features: ['Monthly Bookkeeping', 'Financial Statements', 'Payroll Processing', 'Reconciliations'],
    },
  ];

  return (
    <section className="services-section section-padding" id="services">
      <div className="container">
        <div className="text-center mb-5">
          <div className="section-tag justify-content-center">Our Services</div>
          <h2 className="section-title">Comprehensive Financial <span>Solutions</span></h2>
          <div className="section-divider section-divider-center" />
          <p className="section-desc mx-auto">
            We offer a full spectrum of tax, audit, and financial advisory services tailored 
            to meet the unique needs of your business and personal financial situation.
          </p>
        </div>

        <div className="row g-4">
          {services.map((svc, i) => (
            <div key={i} className="col-lg-4 col-md-6">
              <div className="service-card">
                <div className="service-img-wrapper">
                  <img src={svc.img} alt={svc.title} />
                  <div className="service-img-overlay" />
                  <div className="service-icon-badge">{svc.icon}</div>
                </div>
                <div className="service-body">
                  <h3 className="service-title">{svc.title}</h3>
                  <p className="service-desc">{svc.desc}</p>
                  <div className="d-flex flex-wrap gap-1 mb-3">
                    {svc.features.map((f, fi) => (
                      <span key={fi} style={{
                        background: 'rgba(26,58,92,0.07)',
                        borderRadius: '4px',
                        padding: '3px 10px',
                        fontSize: '0.72rem',
                        fontFamily: 'Montserrat',
                        fontWeight: 600,
                        color: 'var(--primary)',
                      }}>
                        {f}
                      </span>
                    ))}
                  </div>
                  <a href="#contact" className="service-link">
                    Learn More <FaArrowRight size={12} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-5">
          <a href="#contact" className="btn-gold" style={{ textDecoration: 'none', display: 'inline-block' }}>
            Get A Free Quote Today
          </a>
        </div>
      </div>
    </section>
  );
}

/* ========== STATS SECTION ========== */
function StatsSection() {
  const [inView, setInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const stats = [
    { number: 2500, suffix: '+', label: 'Happy Clients' },
    { number: 15, suffix: '+', label: 'Years Experience' },
    { number: 98, suffix: '%', label: 'Client Satisfaction' },
    { number: 50, suffix: '+', label: 'Expert Advisors' },
    { number: 120, suffix: 'M+', label: 'Tax Savings Delivered' },
  ];

  return (
    <section className="stats-section" ref={ref}>
      <div className="container">
        <div className="row justify-content-center align-items-center g-4 text-center">
          {stats.map((stat, i) => (
            <div key={i} className="col-6 col-md-4 col-lg-2 stat-card">
              <div className="stat-number">
                {inView ? (
                  <CountUp end={stat.number} duration={2.5} suffix={stat.suffix} />
                ) : `0${stat.suffix}`}
              </div>
              <div className="stat-label">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========== WHY CHOOSE US ========== */
function WhyChooseUs() {
  const features = [
    {
      icon: <FaAward />,
      title: 'Industry-Leading Expertise',
      text: 'Our team of certified professionals brings decades of combined experience across all sectors and tax jurisdictions.'
    },
    {
      icon: <FaShieldAlt />,
      title: 'Full Regulatory Compliance',
      text: 'We stay ahead of every regulatory change, ensuring your business is always compliant and protected.'
    },
    {
      icon: <FaLightbulb />,
      title: 'Proactive Tax Planning',
      text: 'We don\'t just react to tax issues — we anticipate them, creating strategic plans that save you money year-round.'
    },
    {
      icon: <FaHeadset />,
      title: 'Dedicated Support Team',
      text: 'Your dedicated relationship manager is available whenever you need guidance, advice, or urgent assistance.'
    },
    {
      icon: <FaRegClock />,
      title: 'Timely & Accurate Delivery',
      text: 'We are committed to meeting all deadlines with precision and accuracy, so you never face late filing penalties.'
    },
    {
      icon: <FaTrophy />,
      title: 'Proven Track Record',
      text: 'Over $120M in tax savings delivered to clients across industries — our results speak for themselves.'
    },
  ];

  return (
    <section className="why-section section-padding" id="why-us">
      <div className="container position-relative" style={{ zIndex: 1 }}>
        <div className="row align-items-center g-5">
          <div className="col-lg-5 animate-fade-left">
            <div style={{ position: 'relative', paddingBottom: '20px', paddingRight: '20px' }}>
              <img
                src="/images/why-choose-us.jpg"
                alt="Why Choose Shanu's Tax Consulting"
                style={{
                  width: '100%',
                  height: '520px',
                  objectFit: 'cover',
                  borderRadius: '12px',
                  position: 'relative',
                  zIndex: 2,
                }}
              />
              <div style={{
                position: 'absolute',
                bottom: 0,
                right: 0,
                width: '90%',
                height: '90%',
                border: '3px solid rgba(201, 168, 76, 0.4)',
                borderRadius: '12px',
                zIndex: 1,
              }} />
              <div style={{
                position: 'absolute',
                bottom: '30px',
                left: '30px',
                background: 'linear-gradient(135deg, var(--secondary) 0%, var(--secondary-dark) 100%)',
                borderRadius: '10px',
                padding: '1.2rem 1.5rem',
                zIndex: 3,
                boxShadow: '0 10px 30px rgba(201,168,76,0.4)',
              }}>
                <div style={{
                  fontFamily: 'Playfair Display, serif',
                  fontSize: '1.8rem',
                  fontWeight: 800,
                  color: 'var(--primary-dark)',
                  lineHeight: 1,
                }}>$120M+</div>
                <div style={{
                  fontFamily: 'Montserrat, sans-serif',
                  fontSize: '0.65rem',
                  fontWeight: 700,
                  color: 'var(--primary-dark)',
                  opacity: 0.7,
                  textTransform: 'uppercase',
                  letterSpacing: '1px',
                  marginTop: '4px',
                }}>Tax Savings <br/>Delivered</div>
              </div>
            </div>
          </div>

          <div className="col-lg-7 animate-fade-right">
            <div className="section-tag" style={{ color: 'var(--secondary)' }}>
              <span style={{ background: 'var(--secondary)' }} />
              Why Choose Us
            </div>
            <h2 className="section-title" style={{ color: 'var(--white)' }}>
              The <span>Shanu's Difference</span> — <br/>
              Where Expertise Meets Excellence
            </h2>
            <div className="section-divider" />
            <p className="section-desc mb-4" style={{ color: 'rgba(255,255,255,0.6)' }}>
              We're not just accountants — we're your strategic financial partners, 
              committed to your long-term success.
            </p>

            <div className="row g-3">
              {features.map((f, i) => (
                <div key={i} className="col-12">
                  <div className="why-feature-card">
                    <div className="why-icon">{f.icon}</div>
                    <div>
                      <div className="why-feature-title">{f.title}</div>
                      <div className="why-feature-text">{f.text}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========== PROCESS SECTION ========== */
function ProcessSection() {
  const steps = [
    { icon: '📋', title: 'Initial Consultation', desc: 'We begin with a thorough assessment of your financial situation, understanding your goals and challenges.' },
    { icon: '🔍', title: 'Analysis & Review', desc: 'Our experts conduct an in-depth analysis of your financial data, identifying opportunities and risks.' },
    { icon: '📊', title: 'Strategy Development', desc: 'We develop a customized tax and financial strategy aligned with your business objectives.' },
    { icon: '⚡', title: 'Implementation', desc: 'Our team executes the plan with precision, handling all documentation, filings, and compliance requirements.' },
    { icon: '🔄', title: 'Ongoing Support', desc: 'We provide continuous monitoring, reporting, and advisory support to ensure sustained financial success.' },
  ];

  return (
    <section className="process-section section-padding" id="process">
      <div className="container">
        <div className="text-center mb-5">
          <div className="section-tag justify-content-center">Our Process</div>
          <h2 className="section-title">How We <span>Work</span></h2>
          <div className="section-divider section-divider-center" />
          <p className="section-desc mx-auto">
            Our proven 5-step process ensures every client receives a tailored, 
            comprehensive solution that delivers measurable results.
          </p>
        </div>

        <div className="row g-0">
          {steps.map((step, i) => (
            <div key={i} className="col-12 col-md-6 col-lg-2dot4 text-center position-relative" style={{ flex: '0 0 20%', maxWidth: '20%' }}>
              <div className="process-card">
                <div className="process-step-number">{i + 1}</div>
                <div className="process-icon-circle">
                  <span style={{ fontSize: '2rem' }}>{step.icon}</span>
                </div>
                <h4 className="process-title">{step.title}</h4>
                <p className="process-desc">{step.desc}</p>
              </div>
              {i < steps.length - 1 && (
                <div style={{
                  position: 'absolute',
                  top: '55px',
                  right: '-10%',
                  width: '20%',
                  height: '2px',
                  background: 'linear-gradient(90deg, var(--secondary), rgba(201,168,76,0.2))',
                  zIndex: 0,
                }} className="d-none d-lg-block" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========== INDUSTRIES SECTION ========== */
function IndustriesSection() {
  const industries = [
    { icon: <FaBuilding />, name: 'Real Estate' },
    { icon: <FaHospital />, name: 'Healthcare' },
    { icon: <FaShoppingCart />, name: 'Retail & E-Commerce' },
    { icon: <FaIndustry />, name: 'Manufacturing' },
    { icon: <FaHome />, name: 'Construction' },
    { icon: <FaGraduationCap />, name: 'Education' },
    { icon: <FaTruck />, name: 'Logistics' },
    { icon: <FaHotel />, name: 'Hospitality' },
    { icon: <FaCode />, name: 'Technology' },
    { icon: <FaGlobe />, name: 'Import & Export' },
  ];

  return (
    <section className="industries-section section-padding">
      <div className="container">
        <div className="text-center mb-5">
          <div className="section-tag justify-content-center">Industries We Serve</div>
          <h2 className="section-title">Serving <span>Diverse Industries</span></h2>
          <div className="section-divider section-divider-center" />
          <p className="section-desc mx-auto">
            Our expertise spans across multiple industries, giving us the unique advantage 
            of understanding sector-specific tax challenges and opportunities.
          </p>
        </div>
        <div className="row g-3">
          {industries.map((ind, i) => (
            <div key={i} className="col-6 col-md-4 col-lg-2dot4" style={{ flex: '0 0 20%', maxWidth: '20%' }}>
              <div className="industry-card">
                <span className="industry-icon" style={{ color: 'var(--secondary-dark)', fontSize: '2rem' }}>
                  {ind.icon}
                </span>
                <div className="industry-name">{ind.name}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========== TESTIMONIALS SECTION ========== */
function TestimonialsSection() {
  const testimonials = [
    {
      name: 'Michael Chen',
      role: 'CEO, TechVenture Corp',
      initials: 'MC',
      rating: 5,
      text: 'Shanu\'s Tax Consulting transformed how we handle our corporate tax obligations. Their strategic approach saved us over $200,000 in our first year alone. Absolutely outstanding service!'
    },
    {
      name: 'Sarah Williams',
      role: 'CFO, Global Retail Group',
      initials: 'SW',
      rating: 5,
      text: 'The team\'s expertise in international tax matters is exceptional. They navigated complex cross-border regulations seamlessly and gave us complete peace of mind. Highly recommended!'
    },
    {
      name: 'David Patel',
      role: 'Founder, Patel Real Estate',
      initials: 'DP',
      rating: 5,
      text: 'Professional, knowledgeable, and always available when we need them. Shanu\'s team feels like an extension of our own finance team. Their VAT advisory has been invaluable to our growth.'
    },
    {
      name: 'Amanda Foster',
      role: 'Director, Foster & Associates',
      initials: 'AF',
      rating: 5,
      text: 'The audit services provided by Shanu\'s team were thorough and insightful. They identified process improvements that significantly enhanced our internal controls and financial reporting.'
    },
    {
      name: 'James Okonkwo',
      role: 'MD, Okonkwo Manufacturing',
      initials: 'JO',
      rating: 5,
      text: 'Switching to Shanu\'s Tax Consulting was the best business decision I\'ve made. They handle everything from bookkeeping to strategic tax planning with incredible efficiency and accuracy.'
    },
    {
      name: 'Lisa Tan',
      role: 'Owner, Luxe Hospitality Group',
      initials: 'LT',
      rating: 5,
      text: 'Their CFO services have been a game-changer for our hospitality business. We now have clear financial visibility and a robust tax strategy that supports our expansion plans.'
    },
  ];

  return (
    <section className="testimonials-section section-padding" id="testimonials">
      <div className="container">
        <div className="text-center mb-5">
          <div className="section-tag justify-content-center">Client Reviews</div>
          <h2 className="section-title">What Our <span>Clients Say</span></h2>
          <div className="section-divider section-divider-center" />
          <p className="section-desc mx-auto">
            Don't take our word for it — hear from the businesses and individuals 
            who trust Shanu's for their most critical financial decisions.
          </p>
        </div>

        <div className="row g-4">
          {testimonials.map((t, i) => (
            <div key={i} className="col-lg-4 col-md-6">
              <div className="testimonial-card">
                <div className="testimonial-quote">"</div>
                <div className="testimonial-stars">
                  {Array(t.rating).fill(0).map((_, si) => <FaStar key={si} />)}
                </div>
                <p className="testimonial-text">{t.text}</p>
                <div className="d-flex align-items-center gap-3">
                  <div className="testimonial-avatar">{t.initials}</div>
                  <div>
                    <div className="testimonial-name">{t.name}</div>
                    <div className="testimonial-role">{t.role}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========== TEAM SECTION ========== */
function TeamSection() {
  const team = [
    {
      initials: 'SA',
      name: 'Shanu Ahmed',
      role: 'Founder & Managing Director',
      desc: 'CPA, CA with 20+ years of experience in corporate taxation and financial advisory.'
    },
    {
      initials: 'RK',
      name: 'Riya Kapoor',
      role: 'Head of Tax Advisory',
      desc: 'ACCA certified specialist with deep expertise in VAT and international tax planning.'
    },
    {
      initials: 'MP',
      name: 'Marcus Phillips',
      role: 'Senior Audit Manager',
      desc: 'Former Big-4 auditor with 15+ years of external and internal audit experience.'
    },
    {
      initials: 'NS',
      name: 'Neha Sharma',
      role: 'CFO Services Lead',
      desc: 'MBA Finance expert specializing in virtual CFO services and financial strategy.'
    },
  ];

  return (
    <section className="team-section section-padding" id="team">
      <div className="container">
        <div className="text-center mb-5">
          <div className="section-tag justify-content-center">Our Team</div>
          <h2 className="section-title">Meet Our <span>Expert Advisors</span></h2>
          <div className="section-divider section-divider-center" />
          <p className="section-desc mx-auto">
            Our team of certified professionals brings unmatched expertise, integrity, 
            and dedication to every client engagement.
          </p>
        </div>

        <div className="row g-4 justify-content-center">
          {team.map((member, i) => (
            <div key={i} className="col-lg-3 col-md-6">
              <div className="team-card">
                <div className="team-img-wrapper">
                  <div className="team-avatar-placeholder">{member.initials}</div>
                </div>
                <h4 className="team-name">{member.name}</h4>
                <div className="team-role">{member.role}</div>
                <p style={{ fontFamily: 'Inter', fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.7 }}>
                  {member.desc}
                </p>
                <div className="team-social-links">
                  <a href="#"><FaLinkedin /></a>
                  <a href="#"><FaTwitter /></a>
                  <a href="#"><FaEnvelope /></a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========== CTA SECTION ========== */
function CTASection() {
  return (
    <section className="cta-section">
      <div className="container position-relative" style={{ zIndex: 1 }}>
        <div className="row align-items-center">
          <div className="col-lg-8 text-center text-lg-start mb-4 mb-lg-0">
            <div className="hero-badge" style={{ marginBottom: '1rem' }}>
              <span className="hero-badge-dot" />
              Limited Free Consultations Available
            </div>
            <h2 className="cta-title">
              Ready to Optimize Your <br />
              Tax Position?
            </h2>
            <p className="cta-subtitle">
              Schedule your complimentary consultation today and discover how much you 
              could be saving. Our experts are ready to create your personalized tax strategy.
            </p>
            <div className="d-flex flex-wrap gap-3">
              {[
                { icon: <FaPhone />, label: '+1 (555) 123-4567' },
                { icon: <FaEnvelope />, label: 'info@shanustax.com' },
              ].map((item, i) => (
                <div key={i} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  color: 'rgba(255,255,255,0.8)',
                  fontFamily: 'Montserrat',
                  fontSize: '0.85rem',
                  fontWeight: 600,
                }}>
                  <span style={{ color: 'var(--secondary)' }}>{item.icon}</span>
                  {item.label}
                </div>
              ))}
            </div>
          </div>
          <div className="col-lg-4 text-center">
            <a href="#contact" className="hero-btn-primary" style={{ fontSize: '0.95rem', padding: '1rem 2.5rem', marginBottom: '1rem', display: 'inline-flex' }}>
              Get Free Consultation <FaArrowRight />
            </a>
            <br />
            <a href="tel:+15551234567" className="hero-btn-secondary" style={{ fontSize: '0.85rem', display: 'inline-flex', marginTop: '0.5rem' }}>
              <FaPhone /> Call Us Now
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========== CONTACT SECTION ========== */
function ContactSection() {
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', company: '', service: '', message: ''
  });

const [submitted, setSubmitted] = useState(false);
const [loading, setLoading] = useState(false);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);

  try {
    await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        company: formData.company,
        service: formData.service,
        message: formData.message,
      }),
    });

    setSubmitted(true);
    setFormData({ 
      name: '', 
      email: '', 
      phone: '', 
      company: '', 
      service: '', 
      message: '' 
    });
    setTimeout(() => setSubmitted(false), 4000);

  } catch (error) {
    console.error('Submission error:', error);
    alert('Failed to submit. Please try again.');
  } finally {
    setLoading(false);
  }
};

  const contactItems = [
    { icon: <FaPhone />, label: 'Phone', value: '+1 (555) 123-4567' },
    { icon: <FaWhatsapp />, label: 'WhatsApp', value: '+1 (555) 123-4567' },
    { icon: <FaEnvelope />, label: 'Email', value: 'info@shanustax.com' },
    { icon: <FaMapMarkerAlt />, label: 'Address', value: '123 Financial District, Business Tower, Suite 4500, New York, NY 10004' },
    { icon: <FaClock />, label: 'Office Hours', value: 'Mon–Fri: 8:00 AM – 6:00 PM\nSat: 9:00 AM – 2:00 PM' },
  ];

  return (
    <section className="contact-section section-padding" id="contact">
      <div className="container">
        <div className="text-center mb-5">
          <div className="section-tag justify-content-center">Get In Touch</div>
          <h2 className="section-title">Contact <span>Our Experts</span></h2>
          <div className="section-divider section-divider-center" />
          <p className="section-desc mx-auto">
            Have a question? Ready to start? Reach out to us today and one of our 
            expert advisors will be in touch within 24 hours.
          </p>
        </div>

        <div className="row g-4">
          {/* Contact Info */}
          <div className="col-lg-4">
            <div className="contact-info-card">
              <div className="contact-info-title">Reach Us Directly</div>
              <div className="contact-info-subtitle">Multiple ways to connect with our team</div>
              {contactItems.map((item, i) => (
                <div key={i} className="contact-info-item">
                  <div className="contact-info-icon">{item.icon}</div>
                  <div>
                    <div className="contact-info-label">{item.label}</div>
                    <div className="contact-info-value" style={{ whiteSpace: 'pre-line' }}>{item.value}</div>
                  </div>
                </div>
              ))}
              <div className="mt-4 pt-3" style={{ borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                <div className="contact-info-label mb-2">Follow Us</div>
                <div className="footer-social">
                  <a href="#"><FaLinkedin /></a>
                  <a href="#"><FaTwitter /></a>
                  <a href="#"><FaFacebook /></a>
                  <a href="#"><FaInstagram /></a>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="col-lg-8">
            <div className="contact-form-card">
              <h3 style={{ fontFamily: 'Playfair Display', fontWeight: 700, color: 'var(--primary-dark)', marginBottom: '1.5rem' }}>
                Send Us a Message
              </h3>
              {submitted ? (
                <div className="text-center py-5">
                  <FaCheckCircle style={{ fontSize: '4rem', color: '#4caf50' }} />
                  <h4 className="mt-3" style={{ fontFamily: 'Playfair Display', color: 'var(--primary-dark)' }}>
                    Message Sent Successfully!
                  </h4>
                  <p style={{ color: 'var(--text-muted)', fontFamily: 'Inter' }}>
                    Thank you for reaching out. Our team will contact you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="contact-form-label">Full Name *</label>
                      <input
                        type="text"
                        className="form-control contact-form-input"
                        placeholder="Your full name"
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="contact-form-label">Email Address *</label>
                      <input
                        type="email"
                        className="form-control contact-form-input"
                        placeholder="your@email.com"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="contact-form-label">Phone Number</label>
                      <input
                        type="tel"
                        className="form-control contact-form-input"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="contact-form-label">Company Name</label>
                      <input
                        type="text"
                        className="form-control contact-form-input"
                        placeholder="Your company name"
                        value={formData.company}
                        onChange={e => setFormData({...formData, company: e.target.value})}
                      />
                    </div>
                    <div className="col-12">
                      <label className="contact-form-label">Service Required *</label>
                      <select
                        className="form-control contact-form-input"
                        value={formData.service}
                        onChange={e => setFormData({...formData, service: e.target.value})}
                        required
                      >
                        <option value="">Select a service...</option>
                        <option>Tax Consulting & Planning</option>
                        <option>Auditing & Assurance</option>
                        <option>VAT Services</option>
                        <option>Business Consulting</option>
                        <option>CFO Services</option>
                        <option>Accounting & Bookkeeping</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="contact-form-label">Your Message *</label>
                      <textarea
                        className="form-control contact-form-input"
                        rows={5}
                        placeholder="Describe your requirements in detail..."
                        value={formData.message}
                        onChange={e => setFormData({...formData, message: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-12">

<button 
  type="submit" 
  className="contact-submit-btn"
  disabled={loading}
  style={{ opacity: loading ? 0.6 : 1 }}
>
  {loading ? 'Sending...' : 'Send Message →'}
</button>
                      <span style={{
                        marginLeft: '1rem',
                        fontFamily: 'Inter',
                        fontSize: '0.78rem',
                        color: 'var(--text-muted)',
                      }}>
                        🔒 Your information is 100% confidential
                      </span>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Google Maps Style Placeholder */}
        <div className="row mt-4">
          <div className="col-12">
            <div style={{
              background: 'linear-gradient(135deg, #e8f0fe 0%, #f0f4f8 100%)',
              borderRadius: '12px',
              height: '250px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid var(--border)',
              position: 'relative',
              overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute',
                inset: 0,
                background: 'repeating-linear-gradient(0deg, rgba(26,58,92,0.03) 0px, rgba(26,58,92,0.03) 1px, transparent 1px, transparent 50px), repeating-linear-gradient(90deg, rgba(26,58,92,0.03) 0px, rgba(26,58,92,0.03) 1px, transparent 1px, transparent 50px)',
              }} />
              <div style={{ textAlign: 'center', position: 'relative', zIndex: 1 }}>
                <FaMapMarkerAlt style={{ fontSize: '3rem', color: 'var(--secondary-dark)', marginBottom: '1rem' }} />
                <div style={{ fontFamily: 'Playfair Display', fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-dark)' }}>
                  Shanu's Tax Consulting & Auditing
                </div>
                <div style={{ fontFamily: 'Inter', fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.4rem' }}>
                  123 Financial District, Business Tower, Suite 4500, New York, NY 10004
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========== FOOTER ========== */
function Footer() {
  const services = [
    'Tax Consulting & Planning', 'Auditing & Assurance', 'VAT Services',
    'Business Consulting', 'CFO Services', 'Accounting & Bookkeeping',
    'Payroll Management', 'Transfer Pricing'
  ];

  const quickLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About Us', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Why Choose Us', href: '#why-us' },
    { label: 'Our Team', href: '#team' },
    { label: 'Testimonials', href: '#testimonials' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <footer className="footer">
      <div className="container">
        <div className="row g-5">
          {/* Brand Column */}
          <div className="col-lg-3 col-md-6">
            <div className="d-flex align-items-center gap-2 mb-2">
              <div className="brand-logo-circle" style={{ width: '44px', height: '44px', fontSize: '1.1rem' }}>S</div>
              <div>
                <div className="footer-brand-title">Shanu's Tax</div>
                <div className="footer-brand-sub">Consulting & Auditing</div>
              </div>
            </div>
            <p className="footer-desc">
              Your trusted partner for expert tax consulting, auditing, and financial advisory services. 
              Delivering excellence and compliance with every engagement since 2009.
            </p>
            <div className="footer-social">
              <a href="#"><FaLinkedin /></a>
              <a href="#"><FaTwitter /></a>
              <a href="#"><FaFacebook /></a>
              <a href="#"><FaInstagram /></a>
              <a href="#"><FaWhatsapp /></a>
            </div>
            <div className="mt-3">
              {['CPA Certified', 'ACCA Members', 'CA Certified'].map((cert, i) => (
                <span key={i} style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '5px',
                  background: 'rgba(201,168,76,0.1)',
                  border: '1px solid rgba(201,168,76,0.2)',
                  borderRadius: '4px',
                  padding: '3px 10px',
                  fontFamily: 'Montserrat',
                  fontSize: '0.65rem',
                  fontWeight: 700,
                  color: 'var(--secondary)',
                  margin: '0 4px 4px 0',
                }}>✓ {cert}</span>
              ))}
            </div>
          </div>

          {/* Services Column */}
          <div className="col-lg-3 col-md-6">
            <div className="footer-heading">Our Services</div>
            {services.map((s, i) => (
              <a key={i} href="#services" className="footer-link">
                <span style={{ color: 'var(--secondary)', marginRight: '6px' }}>›</span>{s}
              </a>
            ))}
          </div>

          {/* Quick Links Column */}
          <div className="col-lg-2 col-md-6">
            <div className="footer-heading">Quick Links</div>
            {quickLinks.map((link, i) => (
              <a key={i} href={link.href} className="footer-link">
                <span style={{ color: 'var(--secondary)', marginRight: '6px' }}>›</span>{link.label}
              </a>
            ))}
          </div>

          {/* Contact Column */}
          <div className="col-lg-4 col-md-6">
            <div className="footer-heading">Get In Touch</div>
            {[
              { icon: <FaPhone />, text: '+1 (555) 123-4567' },
              { icon: <FaWhatsapp />, text: '+1 (555) 123-4567 (WhatsApp)' },
              { icon: <FaEnvelope />, text: 'info@shanustax.com' },
              { icon: <FaMapMarkerAlt />, text: '123 Financial District, Business Tower, Suite 4500, New York, NY 10004' },
              { icon: <FaClock />, text: 'Mon–Fri: 8:00 AM – 6:00 PM\nSat: 9:00 AM – 2:00 PM' },
            ].map((item, i) => (
              <div key={i} className="footer-contact-item">
                <span className="footer-contact-icon">{item.icon}</span>
                <span className="footer-contact-text" style={{ whiteSpace: 'pre-line' }}>{item.text}</span>
              </div>
            ))}
            <div className="mt-3">
              <a href="#contact" className="btn-gold" style={{
                textDecoration: 'none',
                display: 'inline-block',
                fontSize: '0.78rem',
                padding: '0.6rem 1.5rem',
              }}>
                Book Consultation →
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="footer-bottom mt-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-6">
              <p className="footer-bottom-text mb-0">
                © {new Date().getFullYear()} <span>Shanu's Tax Consulting & Auditing</span>. All Rights Reserved.
              </p>
            </div>
            <div className="col-md-6 text-md-end mt-2 mt-md-0">
              <span className="footer-bottom-text">
                Privacy Policy · Terms of Service · Cookie Policy
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ========== NAVBAR ========== */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Why Us', href: '#why-us' },
    { label: 'Team', href: '#team' },
    { label: 'Testimonials', href: '#testimonials' },
  ];

  return (
    <>
      {/* Top Bar */}
      <div className="top-bar d-none d-lg-block">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <div className="d-flex gap-4">
              <span className="top-bar-text">🏆 Trusted by 2500+ Clients Worldwide</span>
              <span className="top-bar-text">✔ CPA | CA | ACCA Certified Professionals</span>
            </div>
            <div className="d-flex gap-4">
              <a href="mailto:info@shanustax.com" className="top-bar-contact">
                📧 info@shanustax.com
              </a>
              <a href="tel:+15551234567" className="top-bar-contact">
                📞 +1 (555) 123-4567
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav className={`navbar-custom ${scrolled ? 'scrolled' : ''}`} style={{ top: scrolled ? 0 : '37px' }}>
        <div className="container">
          <div className="d-flex align-items-center justify-content-between w-100">
            {/* Brand */}
            <a href="#home" className="navbar-brand-custom">
              <div className="brand-logo-circle">S</div>
              <div>
                <div className="brand-text-main">Shanu's Tax Consulting</div>
                <div className="brand-text-sub">& Auditing Services</div>
              </div>
            </a>

            {/* Desktop Nav */}
            <div className="d-none d-lg-flex align-items-center gap-1">
              {navLinks.map((link, i) => (
                <a key={i} href={link.href} className="nav-link-custom">{link.label}</a>
              ))}
              <a href="#contact" className="nav-cta-btn ms-2">Free Consultation</a>
            </div>

            {/* Mobile Toggle */}
            <button
              className="d-lg-none btn"
              style={{ color: 'white', fontSize: '1.3rem', border: '1px solid rgba(255,255,255,0.3)', borderRadius: '6px', padding: '4px 10px' }}
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <FaTimes /> : <FaBars />}
            </button>
          </div>

          {/* Mobile Menu */}
          {menuOpen && (
            <div style={{
              background: 'var(--primary-dark)',
              borderTop: '1px solid rgba(255,255,255,0.1)',
              padding: '1rem 0',
              marginTop: '0.5rem',
              borderRadius: '8px',
            }}>
              {navLinks.map((link, i) => (
                <a
                  key={i}
                  href={link.href}
                  className="d-block nav-link-custom"
                  onClick={() => setMenuOpen(false)}
                  style={{ padding: '0.6rem 1rem !important' }}
                >
                  {link.label}
                </a>
              ))}
              <div className="px-3 pt-2">
                <a href="#contact" className="nav-cta-btn d-block text-center" onClick={() => setMenuOpen(false)}>
                  Free Consultation
                </a>
              </div>
            </div>
          )}
        </div>
      </nav>
    </>
  );
}

/* ========== MAIN APP ========== */
export default function App() {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => setShowBackToTop(window.scrollY > 500);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  return (
    <div>
      <Navbar />
      <HeroSection />
      <TickerStrip />
      <AboutSection />
      <ServicesSection />
      <StatsSection />
      <WhyChooseUs />
      <ProcessSection />
      <IndustriesSection />
      <TestimonialsSection />
      <TeamSection />
      <CTASection />
      <ContactSection />
      <Footer />

      {/* Back to Top Button */}
      <button
        className={`back-to-top ${showBackToTop ? 'visible' : ''}`}
        onClick={scrollToTop}
        aria-label="Back to top"
      >
        <FaChevronUp />
      </button>

      {/* WhatsApp Float */}
      <a
        href="https://wa.me/15551234567"
        className="whatsapp-float"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp Chat"
      >
        <FaWhatsapp />
      </a>
    </div>
  );
}
